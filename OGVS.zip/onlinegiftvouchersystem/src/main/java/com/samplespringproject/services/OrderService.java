package com.samplespringproject.services;

import java.util.List;

import com.samplespringproject.dto.GiftCardDTO;
import com.samplespringproject.dto.OrderDTO;

public interface OrderService {
    OrderDTO getOrderById(int id);
    List<OrderDTO> getAllOrders();
    OrderDTO createOrder(OrderDTO orderDTO);
    OrderDTO updateOrder(int id, OrderDTO orderDTO);
    void deleteOrder(int id);
    OrderDTO addGiftCardToOrder(int orderId, GiftCardDTO giftCardDTO); // New operation
	OrderDTO createOrder1(OrderDTO orderDTO);
	OrderDTO updateOrder1(int id, OrderDTO orderDTO);
	OrderDTO addGiftCardToOrder1(int orderId, GiftCardDTO giftCardDTO);
}