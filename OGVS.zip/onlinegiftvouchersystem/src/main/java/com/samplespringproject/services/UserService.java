package com.samplespringproject.services;

import java.util.List;

import com.samplespringproject.dto.UserDTO;

public interface UserService {
    UserDTO getUserById(int id);
    static List<UserDTO> getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}
    UserDTO createUser(UserDTO userDTO);
    UserDTO updateUser(int id, UserDTO userDTO);
    void deleteUser(int id);
    UserDTO updateUserProfile(int id, UserDTO userDTO); // New operation
	UserDTO createUser1(UserDTO userDTO);
	UserDTO updateUser1(int id, UserDTO userDTO);
	UserDTO updateUserProfile1(int id, UserDTO userDTO);
}