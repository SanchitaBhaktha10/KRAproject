package com.samplespringproject.services;


import java.util.List;

import com.samplespringproject.dto.GiftCardDTO;

public interface GiftCardService {
    GiftCardDTO getGiftCardById(int id);
    List<GiftCardDTO> getAllGiftCards();
    GiftCardDTO createGiftCard(GiftCardDTO giftCardDTO);
    GiftCardDTO updateGiftCard(int id, GiftCardDTO giftCardDTO);
    void deleteGiftCard(int id);
    List<GiftCardDTO> searchGiftCards(String query); // New operation
	GiftCardDTO createGiftCard1(GiftCardDTO giftCardDTO);
	GiftCardDTO updateGiftCard1(int id, GiftCardDTO giftCardDTO);
}