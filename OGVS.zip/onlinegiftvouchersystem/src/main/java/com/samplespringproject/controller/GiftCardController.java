package com.samplespringproject.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.samplespringproject.dto.GiftCardDTO;
import com.samplespringproject.services.GiftCardService;

import java.util.List;

@RestController
@RequestMapping("/api/giftcards")
public class GiftCardController {

    @Autowired
    private GiftCardService giftCardService;

    @GetMapping("/{id}")
    public ResponseEntity<GiftCardDTO> getGiftCardById(@PathVariable int id) {
        GiftCardDTO giftCardDTO = giftCardService.getGiftCardById(id);
        return ResponseEntity.ok(giftCardDTO);
    }

    @GetMapping
    public ResponseEntity<List<GiftCardDTO>> getAllGiftCards() {
        List<GiftCardDTO> giftCardDTOs = giftCardService.getAllGiftCards();
        return ResponseEntity.ok(giftCardDTOs);
    }

    @PostMapping
    public ResponseEntity<GiftCardDTO> createGiftCard(@RequestBody GiftCardDTO giftCardDTO) {
        GiftCardDTO createdGiftCardDTO = giftCardService.createGiftCard(giftCardDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdGiftCardDTO);
    }

    @PutMapping("/{id}")
    public ResponseEntity<GiftCardDTO> updateGiftCard(@PathVariable int id, @RequestBody GiftCardDTO giftCardDTO) {
        GiftCardDTO updatedGiftCardDTO = giftCardService.updateGiftCard(id, giftCardDTO);
        return ResponseEntity.ok(updatedGiftCardDTO);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGiftCard(@PathVariable int id) {
        giftCardService.deleteGiftCard(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/search")
    public ResponseEntity<List<GiftCardDTO>> searchGiftCards(@RequestParam String query) {
        List<GiftCardDTO> giftCardDTOs = giftCardService.searchGiftCards(query);
        return ResponseEntity.ok(giftCardDTOs);
    }
}