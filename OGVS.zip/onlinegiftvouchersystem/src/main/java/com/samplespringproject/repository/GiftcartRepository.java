package com.samplespringproject.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.samplespringproject.entity.Giftcart;

@Repository
public interface GiftcartRepository extends JpaRepository<Giftcart, Integer> {
    // Add custom query methods if needed (e.g., find by category)
}