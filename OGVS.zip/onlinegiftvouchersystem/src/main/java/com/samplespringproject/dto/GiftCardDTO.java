package com.samplespringproject.dto;


public class GiftCardDTO {
    private int giftcartId;
    private String category;
    private String giftcartName;
    private int giftcartPrice;
    private int giftcartQuantity;
    private String review;
	public GiftCardDTO() {
		super();
	}
	public GiftCardDTO(int giftcartId, String category, String giftcartName, int giftcartPrice, int giftcartQuantity,
			String review) {
		super();
		this.giftcartId = giftcartId;
		this.category = category;
		this.giftcartName = giftcartName;
		this.giftcartPrice = giftcartPrice;
		this.giftcartQuantity = giftcartQuantity;
		this.review = review;
	}
	public int getGiftcartId() {
		return giftcartId;
	}
	public void setGiftcartId(int giftcartId) {
		this.giftcartId = giftcartId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getGiftcartName() {
		return giftcartName;
	}
	public void setGiftcartName(String giftcartName) {
		this.giftcartName = giftcartName;
	}
	public int getGiftcartPrice() {
		return giftcartPrice;
	}
	public void setGiftcartPrice(int giftcartPrice) {
		this.giftcartPrice = giftcartPrice;
	}
	public int getGiftcartQuantity() {
		return giftcartQuantity;
	}
	public void setGiftcartQuantity(int giftcartQuantity) {
		this.giftcartQuantity = giftcartQuantity;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}

    // Getters and setters
}