package com.samplespringproject.dto;



import java.util.List;

public class OrderDTO {
    private int orderId;
    private String name;
    private String email;
    private String mobileNo;
    private String paymentMethod;
    private int userId; // Use userId instead of the entire User object
    private List<GiftCardDTO> giftCards; // Use GiftCardDTO list

	public OrderDTO() {
		super();
	}

	public OrderDTO(int orderId, String name, String email, String mobileNo, String paymentMethod, int userId,
			List<GiftCardDTO> giftCards) {
		super();
		this.orderId = orderId;
		this.name = name;
		this.email = email;
		this.mobileNo = mobileNo;
		this.paymentMethod = paymentMethod;
		this.userId = userId;
		this.giftCards = giftCards;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public List<GiftCardDTO> getGiftCards() {
		return giftCards;
	}

	public void setGiftCards(List<GiftCardDTO> giftCards) {
		this.giftCards = giftCards;
	}

    // Getters and setters
}