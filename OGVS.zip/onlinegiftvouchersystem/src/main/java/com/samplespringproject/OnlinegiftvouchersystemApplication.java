package com.samplespringproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinegiftvouchersystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinegiftvouchersystemApplication.class, args);
		System.out.println("Welcome");
	}

}
