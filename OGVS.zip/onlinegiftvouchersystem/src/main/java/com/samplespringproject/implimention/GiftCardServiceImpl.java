package com.samplespringproject.implimention;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.samplespringproject.dto.GiftCardDTO;
import com.samplespringproject.entity.Giftcart;
import com.samplespringproject.repository.GiftcartRepository;
import com.samplespringproject.services.GiftCardService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class GiftCardServiceImpl implements GiftCardService {

    @Autowired
    private GiftcartRepository giftcartRepository;

    @Override
    public GiftCardDTO getGiftCardById(int id) {
        Giftcart giftcart = giftcartRepository.findById(id)
                .orElseThrow();
        return mapToDTO(giftcart);
    }

    @Override
    public List<GiftCardDTO> getAllGiftCards() {
        List<Giftcart> giftcarts = giftcartRepository.findAll();
        return giftcarts.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public GiftCardDTO createGiftCard1(GiftCardDTO giftCardDTO) {
        Giftcart giftcart = mapToEntity(giftCardDTO);
        Giftcart savedGiftcart = giftcartRepository.save(giftcart);
        return mapToDTO(savedGiftcart);
    }

    @Override
    public GiftCardDTO updateGiftCard1(int id, GiftCardDTO giftCardDTO) {
        Giftcart giftcart = giftcartRepository.findById(id)
                .orElseThrow();
        // Update entity fields from DTO
        giftcart.setCategory(giftCardDTO.getCategory());
        giftcart.setGiftcartName(giftCardDTO.getGiftcartName());
        giftcart.setGiftcartPrice(giftCardDTO.getGiftcartPrice());
        giftcart.setGiftcartQuantity(giftCardDTO.getGiftcartQuantity());
        giftcart.setReview(giftCardDTO.getReview());

        Giftcart updatedGiftcart = giftcartRepository.save(giftcart);
        return mapToDTO(updatedGiftcart);
    }

    @Override
    public void deleteGiftCard(int id) {
        Giftcart giftcart = giftcartRepository.findById(id)
                .orElseThrow();
        giftcartRepository.delete(giftcart);
    }

    @Override
    public List<GiftCardDTO> searchGiftCards(String query) {
        // Implementation for searching gift cards (e.g., by name or category)
        // You might need to use custom queries in your repository for more complex searches
        return giftcartRepository.findAll().stream()
                .filter(giftcart -> giftcart.getGiftcartName().contains(query) || giftcart.getCategory().contains(query))
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    // Utility methods to map between Entity and DTO
    private GiftCardDTO mapToDTO(Giftcart giftcart) {
        GiftCardDTO giftCardDTO = new GiftCardDTO();
        giftCardDTO.setGiftcartId(giftcart.getGiftcartId());
        giftCardDTO.setCategory(giftcart.getCategory());
        giftCardDTO.setGiftcartName(giftcart.getGiftcartName());
        giftCardDTO.setGiftcartPrice(giftcart.getGiftcartPrice());
        giftCardDTO.setGiftcartQuantity(giftcart.getGiftcartQuantity());
        giftCardDTO.setReview(giftcart.getReview());
        return giftCardDTO;
    }

    private Giftcart mapToEntity(GiftCardDTO giftCardDTO) {
        Giftcart giftcart = new Giftcart();
        giftcart.setCategory(giftCardDTO.getCategory());
        giftcart.setGiftcartName(giftCardDTO.getGiftcartName());
        giftcart.setGiftcartPrice(giftCardDTO.getGiftcartPrice());
        giftcart.setGiftcartQuantity(giftCardDTO.getGiftcartQuantity());
        giftcart.setReview(giftCardDTO.getReview());
        return giftcart;
    }

	@Override
	public GiftCardDTO createGiftCard(GiftCardDTO giftCardDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GiftCardDTO updateGiftCard(int id, GiftCardDTO giftCardDTO) {
		// TODO Auto-generated method stub
		return null;
	}
}