package com.samplespringproject.implimention;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.samplespringproject.dto.UserDTO;
import com.samplespringproject.entity.User;
import com.samplespringproject.repository.UserRepository;
import com.samplespringproject.services.UserService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDTO getUserById(int id) {
        User user = userRepository.findById(id)
                .orElseThrow();
        return mapToDTO(user);
    }

    public List<UserDTO> getAllUsers() {
        List<User> users = userRepository.findAll();
        return users.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public UserDTO createUser1(UserDTO userDTO) {
        User user = mapToEntity(userDTO);
        User savedUser = userRepository.save(user);
        return mapToDTO(savedUser);
    }

    @Override
    public UserDTO updateUser1(int id, UserDTO userDTO) {
        User user = userRepository.findById(id)
                .orElseThrow();
        // Update entity fields from DTO
        user.setUsername(userDTO.getUsername());
        user.setEmail(userDTO.getEmail());

        User updatedUser = userRepository.save(user);
        return mapToDTO(updatedUser);
    }

    @Override
    public void deleteUser(int id) {
        User user = userRepository.findById(id)
                .orElseThrow();
        userRepository.delete(user);
    }

    @Override
    public UserDTO updateUserProfile1(int id, UserDTO userDTO) {
        User user = userRepository.findById(id)
                .orElseThrow();
        //  Only allow specific profile updates (e.g., username, email)
        user.setUsername(userDTO.getUsername());
        user.setEmail(userDTO.getEmail());

        User updatedUser = userRepository.save(user);
        return mapToDTO(updatedUser);
    }

    // Utility methods to map between Entity and DTO
    private UserDTO mapToDTO(User user) {
        UserDTO userDTO = new UserDTO();
        userDTO.setId(user.getId());
        userDTO.setUsername(user.getUsername());
        userDTO.setEmail(user.getEmail());
        return userDTO;
    }

    private User mapToEntity(UserDTO userDTO) {
        User user = new User();
        user.setUsername(userDTO.getUsername());
        user.setEmail(userDTO.getEmail());
        return user;
    }

	@Override
	public UserDTO createUser(UserDTO userDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserDTO updateUser(int id, UserDTO userDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserDTO updateUserProfile(int id, UserDTO userDTO) {
		// TODO Auto-generated method stub
		return null;
	}
}