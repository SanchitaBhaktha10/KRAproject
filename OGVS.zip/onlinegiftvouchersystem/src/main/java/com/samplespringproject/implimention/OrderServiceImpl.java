package com.samplespringproject.implimention;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // Import Transactional

import com.samplespringproject.dto.GiftCardDTO;
import com.samplespringproject.dto.OrderDTO;
import com.samplespringproject.entity.Giftcart;
import com.samplespringproject.entity.Order;
import com.samplespringproject.entity.User;
import com.samplespringproject.repository.GiftcartRepository;
import com.samplespringproject.repository.OrderRepository;
import com.samplespringproject.repository.UserRepository;
import com.samplespringproject.services.OrderService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private GiftcartRepository giftcartRepository;

    @Override
    public OrderDTO getOrderById(int id) {
        Order order = orderRepository.findById(id)
                .orElseThrow();
        return mapToDTO(order);
    }

    @Override
    public List<OrderDTO> getAllOrders() {
        List<Order> orders = orderRepository.findAll();
        return orders.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional // Add Transactional annotation
    public OrderDTO createOrder1(OrderDTO orderDTO) {
        Order order = mapToEntity(orderDTO);
        User user = (User) userRepository.findById(orderDTO.getUserId())
                .orElseThrow();
        order.setUser((org.apache.catalina.User) user);

        Order savedOrder = orderRepository.save(order);

        // Handle Giftcarts:
        if (orderDTO.getGiftCards() != null) {
            for (GiftCardDTO giftCardDTO : orderDTO.getGiftCards()) {
                Giftcart giftcart = mapGiftCardDTOToEntity(giftCardDTO);
                giftcart.setOrder(savedOrder); // Associate with the order
                giftcartRepository.save(giftcart);
            }
        }

        return mapToDTO(savedOrder);
    }

    @Override
    public OrderDTO updateOrder1(int id, OrderDTO orderDTO) {
        Order order = orderRepository.findById(id)
                .orElseThrow();
        // Update entity fields from DTO
        order.setName(orderDTO.getName());
        order.setEmail(orderDTO.getEmail());
        order.setMobileNo(orderDTO.getMobileNo());
        order.setPaymentMethod(orderDTO.getPaymentMethod());

        org.apache.catalina.User user = (org.apache.catalina.User) userRepository.findById(orderDTO.getUserId())
                .orElseThrow();
        order.setUser(user);

        Order updatedOrder = orderRepository.save(order);
        return mapToDTO(updatedOrder);
    }

    @Override
    public void deleteOrder(int id) {
        Order order = orderRepository.findById(id)
                .orElseThrow();
        orderRepository.delete(order);
    }

    @Override
    @Transactional // Add Transactional annotation
    public OrderDTO addGiftCardToOrder1(int orderId, GiftCardDTO giftCardDTO) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow();

        Giftcart giftcart = mapGiftCardDTOToEntity(giftCardDTO);
        giftcart.setOrder(order);
        giftcartRepository.save(giftcart);

        return mapToDTO(order); // Return the updated order
    }

    // Utility methods to map between Entity and DTO
    private OrderDTO mapToDTO(Order order) {
        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderId(order.getOrderId());
        orderDTO.setName(order.getName());
        orderDTO.setEmail(order.getEmail());
        orderDTO.setMobileNo(order.getMobileNo());
        orderDTO.setPaymentMethod(order.getPaymentMethod());
        orderDTO.setUserId(((User) order.getUser()).getId()); // Only send the user ID

        if (order.getGiftCarts() != null) {
            List<GiftCardDTO> giftCardDTOs = order.getGiftCarts().stream()
                    .map(this::mapGiftcartToDTO)
                    .collect(Collectors.toList());
            orderDTO.setGiftCards(giftCardDTOs);
        }

        return orderDTO;
    }

    private Order mapToEntity(OrderDTO orderDTO) {
        Order order = new Order();
        order.setName(orderDTO.getName());
        order.setEmail(orderDTO.getEmail());
        order.setMobileNo(orderDTO.getMobileNo());
        order.setPaymentMethod(orderDTO.getPaymentMethod());
        return order;
    }

    private GiftCardDTO mapGiftcartToDTO(Giftcart giftcart) {
        GiftCardDTO giftCardDTO = new GiftCardDTO();
        giftCardDTO.setGiftcartId(giftcart.getGiftcartId());
        giftCardDTO.setCategory(giftcart.getCategory());
        giftCardDTO.setGiftcartName(giftcart.getGiftcartName());
        giftCardDTO.setGiftcartPrice(giftcart.getGiftcartPrice());
        giftCardDTO.setGiftcartQuantity(giftcart.getGiftcartQuantity());
        giftCardDTO.setReview(giftcart.getReview());
        return giftCardDTO;
    }

    private Giftcart mapGiftCardDTOToEntity(GiftCardDTO giftCardDTO) {
        Giftcart giftcart = new Giftcart();
        giftcart.setGiftcartName(giftCardDTO.getGiftcartName());
        giftcart.setCategory(giftCardDTO.getCategory());
        giftcart.setGiftcartPrice(giftCardDTO.getGiftcartPrice());
        giftcart.setGiftcartQuantity(giftCardDTO.getGiftcartQuantity());
        giftcart.setReview(giftCardDTO.getReview());
        return giftcart;
    }

	@Override
	public OrderDTO createOrder(OrderDTO orderDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderDTO updateOrder(int id, OrderDTO orderDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderDTO addGiftCardToOrder(int orderId, GiftCardDTO giftCardDTO) {
		// TODO Auto-generated method stub
		return null;
	}
}