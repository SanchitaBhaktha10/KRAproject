package com.samplespringproject.entity;



import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.catalina.User;

@Entity
@Table(name = "Order1") // Renamed to avoid conflicts with SQL reserved words
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId;

    private String name;
    private String email;
    private String mobileNo;
    private String paymentMethod;

    @ManyToOne
    private User user;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<Giftcart> giftCarts;

	public Order() {
		super();
	}

	public Order(int orderId, String name, String email, String mobileNo, String paymentMethod, User user,
			List<Giftcart> giftCarts) {
		super();
		this.orderId = orderId;
		this.name = name;
		this.email = email;
		this.mobileNo = mobileNo;
		this.paymentMethod = paymentMethod;
		this.user = user;
		this.giftCarts = giftCarts;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public User getUser() {
		return user;
	}

	
	

	public void setUser(User user) {
		this.user = user;
	}

	public List<Giftcart> getGiftCarts() {
		return giftCarts;
	}

	public void setGiftCarts(List<Giftcart> giftCarts) {
		this.giftCarts = giftCarts;
	}

    // Getters and setters
}
