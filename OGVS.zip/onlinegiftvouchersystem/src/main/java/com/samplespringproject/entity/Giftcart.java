package com.samplespringproject.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Giftcart")
public class Giftcart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int giftcartId;

    private String category;
    private String giftcartName;
    private int giftcartPrice;
    private int giftcartQuantity;
    private String review;

    @ManyToOne
    private Order order;

	public Giftcart() {
		super();
	}

	public Giftcart(int giftcartId, String category, String giftcartName, int giftcartPrice, int giftcartQuantity,
			String review, Order order) {
		super();
		this.giftcartId = giftcartId;
		this.category = category;
		this.giftcartName = giftcartName;
		this.giftcartPrice = giftcartPrice;
		this.giftcartQuantity = giftcartQuantity;
		this.review = review;
		this.order = order;
	}

	public int getGiftcartId() {
		return giftcartId;
	}

	public void setGiftcartId(int giftcartId) {
		this.giftcartId = giftcartId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getGiftcartName() {
		return giftcartName;
	}

	public void setGiftcartName(String giftcartName) {
		this.giftcartName = giftcartName;
	}

	public int getGiftcartPrice() {
		return giftcartPrice;
	}

	public void setGiftcartPrice(int giftcartPrice) {
		this.giftcartPrice = giftcartPrice;
	}

	public int getGiftcartQuantity() {
		return giftcartQuantity;
	}

	public void setGiftcartQuantity(int giftcartQuantity) {
		this.giftcartQuantity = giftcartQuantity;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

    // Getters and setters
}