package com.samplespringproject.exception;

import java.util.Date;


public class ErrorDetails {

	private Date timeStamp;
	private String mesage;
	private String details;//api uri
	public Date getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getMesage() {
		return mesage;
	}
	public void setMesage(String mesage) {
		this.mesage = mesage;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public ErrorDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ErrorDetails(Date timeStamp, String mesage, String details) {
		super();
		this.timeStamp = timeStamp;
		this.mesage = mesage;
		this.details = details;
	}
	
}
